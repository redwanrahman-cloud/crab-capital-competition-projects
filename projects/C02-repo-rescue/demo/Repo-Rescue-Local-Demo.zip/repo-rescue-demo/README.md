# Repo Rescue — run the haunted evidence desk

Compare missing, changed, extra and unchanged file bytes before deciding what to recover. This is the actual local Python tool, with synthetic example inputs. **PLAN ONLY — NO RESTORE.**

Requires Python 3.10 or later. No install, account, internet connection or third-party Python package is needed. On Windows, double-click `run-demo.cmd`, or run:

```text
python -B run_demo.py
```

The launcher executes the real comparison, exports a freshly named HTML report beside this README, and asks your browser to open it locally. If your browser does not open, open that new report yourself. The report contains local input paths: review before sharing.

To run the tool directly from this folder:

```text
python -B app/repo_rescue.py app/fixtures/current app/fixtures/snapshot
python -B app/repo_rescue.py app/fixtures/current app/fixtures/snapshot --format html --output my-report.html
python -B -m unittest discover -s app -p "test_*.py" -v
```

Use a new export name each time; overwrite is refused. The fixture gives exactly one missing, changed, extra and unchanged file. `saved-synthetic-report.html` is an already computed example with only root display labels made generic. Opening it does not execute a comparison. The launcher does.

For your own inputs, use two disjoint, trusted, quiescent folders. Read `app/README.md` first. Links/reparse points, observed changes, unreadable inputs and file/directory type conflicts refuse the complete comparison. No copying, replacement or deletion is implemented. Hashes cannot establish snapshot authenticity. Inputs are not an atomic snapshot.

Fresh November 17 verification: comparison and HTML export succeeded; type-conflict refusal exited 2, with empty stdout and no report. All fixture bytes and checked metadata remained unchanged. The restricted Windows test run passed 20 of 21 tests; the native junction test failed during junction creation with Access denied. The earlier November 16 native run passed all 21. No test or guard was removed. These are local checks, not independent final acceptance.

Codex authored the implementation and presentation. Genuine Kiro work authored the requirements, design and three property tests; Kiro did not author the implementation or visual redesign. Root `.kiro` files are copied unchanged from the approved public source distribution. No new Kiro use or contest sufficiency is claimed.

The Apache-2.0 LICENSE and existing notices are copied unchanged from the approved public source. The third-party notice describes the wider source portfolio; this demo bundle includes no C08 vendor/runtime or external dependencies.

This is a local demo distribution. It is not a hosted scanner, contest entry, video publication or eligibility attestation.
