"""Runs the real comparison, exports a fresh report, opens it locally."""
from datetime import datetime
from pathlib import Path
import subprocess
import sys
import webbrowser
root = Path(__file__).resolve().parent
output = root / ('report-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f') + '.html')
result = subprocess.run([sys.executable, '-B', str(root / 'app/repo_rescue.py'),
    str(root / 'app/fixtures/current'), str(root / 'app/fixtures/snapshot'),
    '--format', 'html', '--output', str(output)])
if result.returncode:
    raise SystemExit(result.returncode)
print('Fresh local comparison report:', output)
webbrowser.open(output.as_uri())
