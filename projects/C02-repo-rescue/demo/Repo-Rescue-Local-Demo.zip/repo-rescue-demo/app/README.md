# Repo Rescue — the haunted evidence desk

A local, read-only file comparison tool. Inspect missing, changed, extra and unchanged file bytes before deciding what to recover. The HTML report uses a ghost to mark missing files whose bytes remain in the supplied snapshot. Text labels carry the same meaning without relying on color or decoration.

**PLAN ONLY — NO RESTORE.** No restore, copy or deletion command exists. No account, server, remote assets or dependency installation is needed.

## Run

Requires Python 3.10 or later (standard library only). From the repository root:

```powershell
python -B app/repo_rescue.py app/fixtures/current app/fixtures/snapshot
python -B app/repo_rescue.py app/fixtures/current app/fixtures/snapshot --format html --output report.html
python -B -m unittest discover -s app -p 'test_*.py' -v
```

Open `report.html` locally in a browser. Use a fresh output name each time: export refuses overwrite and writes only outside both input trees. The synthetic example produces one file in each classification. `--format html` without `--output` prints HTML. Exit 0 means completed comparison; exit 2 means refusal or invalid arguments. Differences do not cause a failing exit.

The report includes full SHA256 hashes, clear proposal cards and expandable exact proposal bindings. It contains no scripts, forms, restore buttons or external resources. The comparison ledger scrolls horizontally on narrow screens. Keyboard users can focus the ledger and native disclosure controls.

## Real folders

Use two distinct, non-overlapping, quiescent directories you trust. All files are included, including hidden files and `.git`; no silent exclusions apply. Four complete tree reads across the two inputs are required. No progress UI or size limit is implemented.

Observed symlinks, Windows junctions/reparse points, special files, linked ancestors, ambiguous Windows paths, read/permission failures and file-versus-directory collisions refuse the whole comparison. No partial report or plan is emitted. Export failure may leave a partial NEW report, never an input write.

Extra current files require a separate keep-or-remove decision. Replacement proposals require backup and separate human approval. Snapshot trust is supplied by the user; hashes establish neither authenticity nor completeness.

## Limits

Two scans and file metadata checks detect tested observable changes; they do not provide an atomic snapshot or defeat adversarial races. Stop other writers first. File bytes, membership, modification times and modes are checked unchanged by tests; ordinary reads may update access times. Permissions, empty-directory restoration, hard-link topology and ownership are not restored or certified. No novelty or advantage over manual hashing has been measured.

The native Windows junction test creates and removes a temporary junction. Restricted execution environments can deny junction creation before the rejection assertions run. Report that setup failure honestly; do not weaken the guard or treat it as passing.

## Development attribution

Codex authored the core implementation, earlier file/directory correction and haunted report presentation. A genuine Kiro desktop session authored the retained requirements, design and three fixed-seed generated-case property tests in `.kiro/specs/repo-rescue/` and `app/test_kiro_properties.py`. Those tests cover stable regular-file classification/hash equivalence, unchanged input bytes, determinism and boundary disclosure. They did not discover the earlier type-conflict defect. Kiro did not author the core or this report redesign. No Kiro hook, MCP, custom agent, Crew or power use is claimed. Contest Kiro-use sufficiency and category acceptance remain judges' decisions.

Internal historical receipts are excluded from the suggested public source subset because they contain machine paths and operational context. The retained `.kiro` specifications contain historical local execution context; review them before public release and preserve attribution if a separate redacted copy is prepared. This repository is a desktop test build, not a hosted scanner or a claim of submitted contest acceptance.
