@echo off
cd /d "%~dp0"
python -B run_demo.py
if errorlevel 1 pause
